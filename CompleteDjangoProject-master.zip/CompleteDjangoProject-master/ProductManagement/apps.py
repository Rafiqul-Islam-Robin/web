from django.apps import AppConfig


class ProductmanagementConfig(AppConfig):
    name = 'ProductManagement'
